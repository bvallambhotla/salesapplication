﻿using Profisee.Application.Common.Models;

namespace Application.Customers.Models
{
    public class CustomerLite: Lookup
    {
    }
}
