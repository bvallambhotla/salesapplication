﻿using Profisee.Application.Common.Models;

namespace Application.SalesPerson.Models;
public class SalespersonLite : Lookup
{
}
