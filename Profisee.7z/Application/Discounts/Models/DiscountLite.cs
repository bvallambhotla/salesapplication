﻿using Profisee.Application.Common.Models;

namespace Application.Products.Models;
public class DiscountLite : Lookup
{
}
