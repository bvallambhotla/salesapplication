﻿using MediatR;

namespace Profisee.Domain.Common;

public abstract class BaseEvent : INotification
{
}
